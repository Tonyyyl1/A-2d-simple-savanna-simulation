# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

非洲草原捕食者-猎物生态模拟（Java + 原 BlueJ 工程）。将经典 foxes-and-rabbits 模型扩展为五物种（Lion / Cheetah / Zebra / Buffalo / Gazelle）生态系统，含天气、疾病、草料、食物链捕食、繁殖、体力、生存压力、可视化、图表、HTML 报告，以及一个零依赖测试套件。

构建系统是手写的 `javac`，**没有** Maven / Gradle / JUnit。源码、`.class`、`.ctxt`（BlueJ 上下文）、`package.bluej` 全部平铺在仓库根目录（无 `src/`、无 package 声明，全部 default package）。

## Commands

```bash
# 编译（在源码根目录）
javac *.java

# 运行可视化模拟（默认 200000 步）
java VisualSimulationRunner
java VisualSimulationRunner 5000        # 较短的可视化运行

# 无界面长跑稳定性验证
java SimulationRunner 200000

# 测试套件（零依赖，纯 Java）
java AllTests                            # 单元 + 系统 + 1000 步稳定性
java AllTests full                       # 额外加 5000 步稳定性

# 从打包 JAR 运行
java -jar savanna-simulation.jar 5000
```

单独跑某一类测试：`AllTests` 聚合 `SimulationUnitTests` / `SimulationSystemTests` /
`SimulationIntegrationTests`，可直接 `java SimulationUnitTests` 等单独运行其 `main`。

推荐调参流程（先便宜后昂贵，避免直接长跑）：
`java AllTests` → `java AllTests full` → 大改参数后才 `java SimulationRunner 200000`。

## Architecture

**时间模型**：`1 step = 1 模拟小时`，`24 步 = 1 天`。生态模型每步都算，**可视化每 100 步才刷新一次**（性能）。

**核心循环**：`Simulator.java` 持有 `Field`（动物的网格世界，默认 80 深 × 120 宽）、
`SimulationContext`（共享系统 + 步级状态）、可选的 `SimulatorView`。每步 `context.startStep()`
推进时钟/天气/草料增长，然后遍历动物行为。

**系统通过接口 + 实现类解耦**，全部由 `SimulationContext` 持有并注入：

| 接口 | 实现 |
|------|------|
| `WeatherSystem` | `SeasonalWeatherSystem` |
| `DiseaseSystem` | `SavannahDiseaseSystem` |
| `FoodSystem` | `GrasslandFoodSystem` |
| `PredationSystem` | `FoodChainPredationSystem` |
| `BreedingSystem` | `MateFindingBreedingSystem` |
| `SimulationRecorder` | `StepReportRecorder` / `WindowedSimulationRecorder` / `NullSimulationRecorder` |

物种参数集中在 `SpeciesRegistry` + `SpeciesProfile`（`BasicSpeciesProfile`）。共享动物行为在
`SavannahAnimal`（具体物种 `Lion`/`Zebra`/… 仅是薄壳）。`Animal` 是顶层抽象。

**可视化三层**（关键，见下方注意点）：`SimulatorView.FieldView` 把渲染分成
①地形背景层（`TerrainMap.drawBackground()` 画进缓存的 `terrainImage`）、
②动物层（`animalImage`，透明，含聚合人口压力块 + 代表性个体符号）、
③天气/时间着色 + 指标面板叠加。`paintComponent` 把两张 `BufferedImage` 叠加绘制。

**记录与报告**：`StepReportRecorder` 每 100 步快照，最终生成
`savanna-simulation-step-report.html`。无界面跑由 `SimulationRunner` 每 100 步打印诊断行
（`SimulationDiagnostics`）。

## ⚠️ 已知结构性问题（地形渲染）

`TerrainMap` 内部有**两套互不一致的地形表示**：

1. `terrain[][]`（`classify()` 逐格分类）— 供 `getTerrainAt()` / `countTerrainTypes()` 的**逻辑真值**。
2. `drawBackground()` — 一组**独立硬编码**的矢量曲线/椭圆（坐标如 `width*0.66`），与 `terrain[][]` 的数学**完全无关**。

因此「背景图看到的区块形状」并不等于「网格里真实的地形分类」。README 中描述的
"为每个区块生成 2.5D 图像再拼接" 实际未实现 —— 当前是装饰性矢量绘制。修改地形时务必让两者
保持一致，理想做法是让背景渲染**从 `terrain[][]` 派生**（按区块上色后拼接 + 2.5D 光照），
而非维护第二套坐标。

注意：地形目前**纯视觉**，不参与草料/移动/疾病/捕食/繁殖逻辑（README 标注留待后续阶段）。
