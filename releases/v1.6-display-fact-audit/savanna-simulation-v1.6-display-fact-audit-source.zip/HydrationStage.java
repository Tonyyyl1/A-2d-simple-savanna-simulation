/** Three-stage hydration state used by thirst decisions and diagnostics. */
public enum HydrationStage
{
    NORMAL,
    THIRSTY,
    CRITICAL
}
