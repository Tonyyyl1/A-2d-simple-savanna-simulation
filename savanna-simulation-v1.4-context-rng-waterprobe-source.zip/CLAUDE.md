# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

非洲草原捕食者-猎物生态模拟（Java + 原 BlueJ 工程）。将经典 foxes-and-rabbits 模型扩展为五物种（Lion / Cheetah / Zebra / Buffalo / Gazelle）生态系统，含天气、疾病、草料、食物链捕食、繁殖、体力、生存压力、可视化、图表、HTML 报告，以及一个零依赖测试套件。

构建系统是手写的 `javac`，**没有** Maven / Gradle / JUnit。源码、`.class`、`.ctxt`（BlueJ 上下文）、`package.bluej` 全部平铺在仓库根目录（无 `src/`、无 package 声明，全部 default package）。

## Commands

```bash
# 编译/测试/打包（在源码根目录）
./build.sh
./test.sh
./package.sh v1.4-terrain-habitat
./verify-jar.sh v1.4-terrain-habitat

# 运行可视化模拟（默认 200000 步）
java VisualSimulationRunner
java VisualSimulationRunner 5000        # 较短的可视化运行

# 无界面长跑稳定性验证
java SimulationRunner 200000

# 测试套件（零依赖，纯 Java）
java AllTests                            # 单元 + 系统 + 1000 步稳定性
java AllTests full                       # 额外加 5000 步稳定性

# 从打包 JAR 运行
java -jar /Users/tony/Documents/Codex/2026-06-26/fan/outputs/savanna-simulation-v1.4-terrain-habitat.jar

# 当前 v1.4 水面安全验证（三项都必须为 0）
java -cp /Users/tony/Documents/Codex/2026-06-26/fan/outputs/savanna-simulation-v1.4-terrain-habitat.jar WaterSafetyProbe 1000 100
java -cp /Users/tony/Documents/Codex/2026-06-26/fan/outputs/savanna-simulation-v1.4-terrain-habitat.jar WaterSafetyProbe 18500 500
```

单独跑某一类测试：`AllTests` 聚合 `SimulationUnitTests` / `SimulationSystemTests` /
`SimulationIntegrationTests`，可直接 `java SimulationUnitTests` 等单独运行其 `main`。

推荐调参流程（先便宜后昂贵，避免直接长跑）：
`java AllTests` → `java AllTests full` → 大改参数后才 `java SimulationRunner 200000`。

## Current v1.4 State

当前交付 jar：

`/Users/tony/Documents/Codex/2026-06-26/fan/outputs/savanna-simulation-v1.4-terrain-habitat.jar`

该 jar 的 manifest 是 `Main-Class: VisualSimulationRunner`。直接 `java -jar ...` 会进入启动配置界面；正式默认配置为 `SimulationConfig.default3x()` / `target3xBalanced()`，即 3x 地图，默认 random seed `1111`，terrain seed `20260629`。普通可视化入口不应再回到 1x。

最近一次已验证状态（Jul 7，热力图 UI + 统一视觉几何修复后）：

- 工作目录 `.class`：
  - `./test.sh` -> `167/167` passed
  - `java WaterSafetyProbe 1000 100` -> 每个检查点三项均为 `0`
  - `java WaterSafetyProbe 18500 500` -> step 0 到 18500，每 500 步三项均为 `0`
- 打包后必须重新跑 jar 自身验证；不要用工作目录 `.class` 结果替代 jar 结果。

`WaterSafetyProbe` 现在不是只扫动物中心格。它必须同时验证三项：

1. `water animals == 0`
   - 真实 `Field` 中 alive animal 的 `location` 不在 `WATERHOLE`。
2. `ordinary visual water samples == 0`
   - 普通模拟层的小点/三角 marker 的最终绘制 footprint 不压到视觉水面。
   - 这个专门对应用户截图里“小点看起来在水池里”的问题。
3. `visual water samples == 0`
   - inspect/行为 actor 的逐帧动画 footprint 不扫过水面。

以后凡是改地形、普通绘制、inspect 绘制、SceneDirector 动画、移动/捕食/繁殖，都不能只跑中心格水审计；必须跑至少：

```bash
./build.sh
./test.sh
java WaterSafetyProbe 1000 100
```

打 jar 后还要用 jar 自己再跑：

```bash
./package.sh v1.4-terrain-habitat
./verify-jar.sh v1.4-terrain-habitat
```

## Architecture

**时间模型**：`1 step = 1 模拟小时`，`24 步 = 1 天`。生态模型每步都算，**可视化每 100 步才刷新一次**（性能）。

**核心循环**：`Simulator.java` 持有 `Field`（动物的网格世界，当前正式默认 3x 为 240 深 × 360 宽；baseline 仍可用于测试/对比）、
`SimulationContext`（共享系统 + 步级状态）、可选的 `SimulatorView`。每步 `context.startStep()`
推进时钟/天气/草料增长，然后遍历动物行为。

**系统通过接口 + 实现类解耦**，全部由 `SimulationContext` 持有并注入：

| 接口 | 实现 |
|------|------|
| `WeatherSystem` | `SeasonalWeatherSystem` |
| `DiseaseSystem` | `SavannahDiseaseSystem` |
| `FoodSystem` | `GrasslandFoodSystem` |
| `PredationSystem` | `FoodChainPredationSystem` |
| `BreedingSystem` | `MateFindingBreedingSystem` |
| `SimulationRecorder` | `StepReportRecorder` / `WindowedSimulationRecorder` / `NullSimulationRecorder` |

物种参数集中在 `SpeciesRegistry` + `SpeciesProfile`（`BasicSpeciesProfile`）。共享动物行为在
`SavannahAnimal`（具体物种 `Lion`/`Zebra`/… 仅是薄壳）。`Animal` 是顶层抽象。

**地形与移动**：`SimulationContext` 按 `SimulationConfig.getTerrainSeed()` 创建 `TerrainMap`。`TerrainMap.isPassable()` 以 `WATERHOLE` 为不可通行。初始化、founder placement、普通移动、繁殖位置、觅食候选、捕食候选和最终放置兜底都应走 passable 过滤。`TerrainNavigator` 提供地形感知邻格、range 搜索和一次 BFS reachability；`FoodChainPredationSystem` 每个 predator hunt 应只建一次 reachability，不要每个猎物重复 BFS。

**栖息地偏好**：`HabitatPreferences` 参与 spawn / movement / grazing / hunting。偏好是强权重，不是硬边界。水塘仍不可通行。

**可视化层**（关键）：`SimulatorView.FieldView` 把渲染分成地形背景层 `terrainImage`、普通动物 marker 层 `animalImage`、weather/time/metric overlay，以及 inspect actor 层。

- 普通模式：画 `terrainImage` + `animalImage`。
- inspect 模式：只画地形和 inspect actor，不再叠加普通小点层。
- 地形、普通动物、inspect actor、点击命中和 probe 必须共享 `VisualGridGeometry` / `VisualFootprint`。不要再直接用 `xScale/yScale` 自己算动物格子；地形格、动物 marker、probe 都要使用同一套 rounded cell bounds。
- 普通动物 marker 绘制前必须通过 `VisualWaterMask.ordinaryAnimalFootprintTouchesWater()`；该类现在是 `VisualFootprint.ordinaryTouchesWater()` 的兼容薄壳。岸边 `GRASSLAND` 格子如果 marker footprint 会压到视觉水面，就不能画。
- inspect actor 由 `SceneDirector` 生成；当前要求显示 viewport 内所有可见动物 actor，不再裁到 20 个。高密度时只能稀疏低优先级 `forage` / `prowl` 文本，不能减少动物图标。
- `SceneDirector` 会 sanitize keyframes；若 actor 端点安全但插值轨迹扫水，会折叠到安全陆地 footprint，避免动画扫过水面。
- 放大模式点击 inspect actor 图标会打开 `AnimalStatusLog` 中英双语状态表。点击命中必须基于屏幕上的 actor footprint，而不是只按 `Field` 中心格。

**记录与报告**：`StepReportRecorder` 每 100 步快照，最终生成
`savanna-simulation-step-report.html`。无界面跑由 `SimulationRunner` 每 100 步打印诊断行
（`SimulationDiagnostics`）。

**事件与长期观测**：`SimulationContext.recentEvents` 仍然是最近窗口，最大 600 条，只适合
inspect actor、最近行为文本和近期统计。长期热力图、回放索引、全程事件统计必须用
`SimulationEventListener` + `EventAccumulator`，不要从 `recentEvents` 反推全程历史。
`Simulator` 保存 listener 注册表并在 `reset()` 重建 `SimulationContext` 后重新挂载，避免观察器
丢失。当前 GUI 已在控制栏提供 `Heatmap / 热力图` 开关和事件类型下拉；热力图画在地形层之上、
普通动物/inspect actor 之下，按 `EventAccumulator` 的全程事件计数绘制，并跳过不可通行水塘格。

**快照基础**：`AnimalSnapshot` / `SimulationSnapshot` / `SnapshotRecorder` 是不可变状态快照
基础，用于后续时间轴、回放和导出。不要把 `Field`、`Animal` 或 `SimulationContext` 的可变引用
直接存成“历史快照”。

## Critical Notes For Future Agents

- 不要再声称“动物不在水里”只因为 `animal.location` 不在 `WATERHOLE`。用户截图反复暴露的是最终可视 footprint 压到视觉水面。
- `WaterSafetyProbe` 的三项输出都必须是 0，少一项都不算完成。
- `VisualGridGeometry` 是地形/动物/probe 的共享坐标层，使用和 `TerrainMap.buildRegions()` 一致的 rounded cell bounds，专门防止非整除窗口尺寸下的坐标错位。
- `VisualFootprint` 是普通 marker 和 inspect actor 的共享 footprint 层。`SimulatorView`、`SceneDirector`、`VisualWaterMask`、`WaterSafetyProbe` 都应调用它，不要复制采样逻辑。
- `VisualWaterMask` 当前用 `TerrainMap.isVisuallyWaterAt()` + `VisualFootprint` 对普通 marker footprint 做快速水面判定，避免为了测试去渲染巨大的 AWT image。
- 如果修改 `TerrainMap.drawWaterhole()` 的视觉形状，必须同步 `TerrainMap.isVisuallyWaterAt()` / `VisualWaterMask`，否则测试和截图会再次不一致。
- 如果修改普通 marker 尺寸、阴影、缩放规则，必须同步 `VisualFootprint.ordinaryMarker()` / `VisualFootprint.ordinaryBounds()`。
- 如果修改 inspect actor 尺寸、锚点、插值、marker 逻辑，必须同步 `VisualFootprint.inspectActorTouchesWater()` / `VisualFootprint.inspectIconPixels()` 和相关 probe。
- 打包后必须验证 jar 本身，而不是只验证工作目录 `.class`。
- `recentEvents` 只保留 600 条。热力图/回放/长期统计不能依赖它；必须接事件监听器或不可变快照。
- 热力图绘制必须继续使用 `VisualGridGeometry.cellBounds()`，不能复制新的 row/col 到 pixel 公式。

## User Workflow Preference

When the user asks for `xhigh`, deep reasoning, architecture review, or says not to edit directly, first output a concrete execution plan and do not modify files.

The plan must include:
- Problem hypothesis and main suspect areas.
- Files to inspect.
- Step-by-step executable commands or code snippets.
- Architecture boundaries and intended changes.
- Verification strategy, including whether checks run against workspace `.class` files or the packaged jar.
- A clear note that implementation starts only after user confirmation.

For repeated visual/water/coordinate bugs, assume the root cause may be geometry mismatch between logical Field coordinates, terrain rendering, animal rendering, zoom transforms, and probe sampling. Do not claim the issue is fixed until all relevant layers are audited.
